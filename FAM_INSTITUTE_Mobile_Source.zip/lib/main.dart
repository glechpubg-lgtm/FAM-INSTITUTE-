
import 'package:flutter/material.dart';

const navy = Color(0xFF18345F);
const green = Color(0xFF70A443);

void main() => runApp(const FamInstituteApp());

class FamInstituteApp extends StatelessWidget {
  const FamInstituteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FAM INSTITUTE',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: navy, primary: navy, secondary: green),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selected = 0;
  final lessons = const [
    Lesson('دووشەممە', '08:30 – 10:00', 'کۆمپیوتەر', 'مامۆستا: نموونە', 'A-101'),
    Lesson('دووشەممە', '10:15 – 11:45', 'زمانی ئینگلیزی', 'مامۆستا: نموونە', 'B-204'),
    Lesson('سێشەممە', '09:00 – 10:30', 'بیرکاری', 'مامۆستا: نموونە', 'A-102'),
    Lesson('چوارشەممە', '08:30 – 10:00', 'پرۆگرامسازی', 'مامۆستا: نموونە', 'Lab 1'),
    Lesson('پێنجشەممە', '11:00 – 12:30', 'ئامادەکاری', 'مامۆستا: نموونە', 'A-103'),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [_home(), _timetable(), _simplePage('هەواڵ و ئاگاداری'), _simplePage('هەژمار')];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: true,
          title: const Text('FAM INSTITUTE', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        body: pages[selected],
        bottomNavigationBar: NavigationBar(
          selectedIndex: selected,
          onDestinationSelected: (value) => setState(() => selected = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'سەرەتا'),
            NavigationDestination(icon: Icon(Icons.calendar_month), label: 'خشتەی وانە'),
            NavigationDestination(icon: Icon(Icons.campaign_outlined), label: 'هەواڵ'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'هەژمار'),
          ],
        ),
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(20)),
        child: Column(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.asset('assets/fam_logo.jpg', height: 125, fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => const Icon(Icons.school, size: 70, color: Colors.white)),
          ),
          const SizedBox(height: 10),
          const Text('FAM INSTITUTE – RANYA',
            style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)),
          const Text('بەخێربێیت بۆ پەیمانگای FAM',
            style: TextStyle(color: Colors.white70)),
        ]),
      ),
      const SizedBox(height: 20),
      const Text('بەشە سەرەکییەکان',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: navy)),
      const SizedBox(height: 10),
      _menu(Icons.calendar_month, 'خشتەی وانەکان', 'کاتی وانە و پۆلەکان', () => setState(() => selected = 1)),
      _menu(Icons.campaign, 'هەواڵ و ئاگاداری', 'نوێترین بڵاوکراوەکانی پەیمانگا', () => setState(() => selected = 2)),
      _menu(Icons.menu_book, 'وانە و فایلەکان', 'PDF و ماددەی خوێندن', () {}),
      _menu(Icons.assignment, 'ئەرکەکان', 'ئەرک و ڕاهێنانەکان', () {}),
    ],
  );

  Widget _timetable() => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('خشتەی وانەکان',
        style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: navy)),
      const SizedBox(height: 6),
      const Text('خشتەی نموونەیی — کات و وانەکان لە وەشانی داهاتوودا لەلایەن مامۆستا نوێ دەکرێنەوە.'),
      const SizedBox(height: 14),
      ...lessons.map((lesson) => Card(
        margin: const EdgeInsets.only(bottom: 11),
        child: ListTile(
          leading: const CircleAvatar(backgroundColor: green,
            child: Icon(Icons.menu_book, color: Colors.white)),
          title: Text(lesson.subject, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${lesson.day} • ${lesson.teacher}\nژوور: ${lesson.room}'),
          isThreeLine: true,
          trailing: Text(lesson.time,
            style: const TextStyle(color: navy, fontWeight: FontWeight.bold)),
        ),
      )),
    ],
  );

  Widget _simplePage(String title) => Center(
    child: Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
  );

  Widget _menu(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(
    child: ListTile(
      onTap: onTap,
      leading: Icon(icon, color: green, size: 30),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_left),
    ),
  );
}

class Lesson {
  final String day, time, subject, teacher, room;
  const Lesson(this.day, this.time, this.subject, this.teacher, this.room);
}
