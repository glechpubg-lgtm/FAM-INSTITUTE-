FAM INSTITUTE – وەشانی سەرەتایی بۆ مۆبایل

ئەمە سەرچاوەی ئەپی Flutter ـە، نەک APK ـی ئامادە.

بۆ دروستکردنی APK:
1) فایلە ZIP ـەکە بکەوە.
2) ناوەڕۆکەکە لە GitHub repository ـێکی نوێدا Upload بکە.
3) لە GitHub بچۆ بۆ Actions.
4) کاری "Build FAM INSTITUTE APK" هەڵبژێرە و Run workflow بکە.
5) دوای تەواوبوون، لە Artifacts فایلێکی fam-institute-release-apk دابگرە.
6) APK ـەکە لە Downloads ـی مۆبایل دایبمەزرێنە.

پێویستە GitHub account هەبێت. ئەم وەشانە UI ـی سەرەتایی و خشتەی وانەی نموونەییە؛
هێشتا Login، Admin/Teacher/Student accounts، class join codes و backendی چالاکی تێدا نییە.
